# Быстрый старт OperaX Browser

## 1. Запуск на ПК (Electron)

```bash
# Установка зависимостей
npm install

# Сборка
npm run build

# Установка Electron
npm install electron --save-dev

# Запуск
npx electron electron-main.js
```

## 2. Запуск на Android

### Вариант A: PWA (2 минуты)
1. Залейте папку `dist/` на хостинг (GitHub Pages, Netlify)
2. Откройте сайт в Chrome на телефоне
3. Меню → "Добавить на главный экран"

### Вариант B: Нативное приложение (30 минут)
1. Скопируйте `dist/` в `android-project/app/src/main/assets/browser/`
2. Соберите APK в Android Studio
3. Подробности в `ANDROID_GUIDE.md`

## 3. Создание ZIP-архива

### Windows:
```batch
create-zip.bat
```

### macOS / Linux:
```bash
bash create-zip.sh
```

Архив `operax-browser.zip` будет содержать все файлы проекта.

## Горячие клавиши

| Клавиша | Действие |
|---------|----------|
| Ctrl+T | Новая вкладка |
| Ctrl+W | Закрыть вкладку |
| Ctrl+L | Фокус на адресную строку |
| Alt+← | Назад |
| Alt+→ | Вперёд |
| F5 | Обновить |

## Структура проекта

```
├── dist/               ← Готовые файлы (сюда смотреть для Android!)
├── src/                ← Исходный код React
├── electron-main.js    ← Electron
├── preload.js          ← Безопасность Electron
├── package.json        ← Зависимости
└── *.md                ← Инструкции
```
