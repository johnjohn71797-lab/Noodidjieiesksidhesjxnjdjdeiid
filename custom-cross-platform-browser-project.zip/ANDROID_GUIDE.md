# Инструкция по сборке OperaX Browser для Android

## Быстрый старт (рекомендуется)

### Способ 1: Android Studio (полноценное приложение)

#### Шаг 1: Установите Android Studio
Скачайте с https://developer.android.com/studio

#### Шаг 2: Создайте проект
1. Откройте Android Studio → **New Project**
2. Выберите шаблон **Empty Views Activity**
3. Название: `OperaX Browser`
4. Package name: `com.operax.browser`
5. Minimum SDK: **API 26: Android 8.0 (Oreo)**
6. Language: **Kotlin**
7. Finish

#### Шаг 3: Добавьте зависимости
В файл `app/build.gradle` (Module: app) в раздел `dependencies` добавьте:

```gradle
dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.webkit:webkit:1.9.0'
    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.1.5'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'
}
```

Нажмите **Sync Now**.

#### Шаг 4: Разрешения
В `app/src/main/AndroidManifest.xml` добавьте перед `<application>`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

#### Шаг 5: Разметка экрана
Замените содержимое `app/src/main/res/layout/activity_main.xml`:

```xml
<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout 
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#1e1e1e">

    <WebView
        android:id="@+id/webview"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

    <ProgressBar
        android:id="@+id/progressBar"
        style="@style/Widget.AppCompat.ProgressBar.Horizontal"
        android:layout_width="match_parent"
        android:layout_height="3dp"
        android:layout_alignParentTop="true"
        android:progressDrawable="@drawable/progress_gradient"
        android:visibility="gone" />
</RelativeLayout>
```

Создайте файл `app/src/main/res/drawable/progress_gradient.xml`:

```xml
<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:id="@android:id/progress">
        <clip>
            <shape>
                <solid android:color="#ff4b4b" />
            </shape>
        </clip>
    </item>
</layer-list>
```

#### Шаг 6: Код MainActivity
Замените `app/src/main/java/com/operax/browser/MainActivity.kt`:

```kotlin
package com.operax.browser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)
        progressBar = findViewById(R.id.progressBar)

        val webSettings: WebSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.databaseEnabled = true
        webSettings.allowFileAccess = true
        webSettings.allowContentAccess = true
        webSettings.cacheMode = WebSettings.LOAD_DEFAULT
        webSettings.useWideViewPort = true
        webSettings.loadWithOverviewMode = true
        webSettings.setSupportZoom(true)
        webSettings.builtInZoomControls = true
        webSettings.displayZoomControls = false
        webSettings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress == 100) {
                    progressBar.visibility = View.GONE
                } else {
                    progressBar.visibility = View.VISIBLE
                }
            }
        }

        // Загрузка локального HTML из assets
        webView.loadUrl("file:///android_asset/browser/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }
}
```

#### Шаг 7: Копирование файлов браузера
1. Выполните сборку веб-приложения: `npm run build`
2. В Android Studio создайте папку: `app/src/main/assets/browser/`
3. Скопируйте ВСЕ файлы из папки `dist/` проекта в `app/src/main/assets/browser/`

Структура должна быть такой:
```
app/src/main/assets/browser/
├── index.html
└── (остальные файлы из dist)
```

#### Шаг 8: Сборка APK
1. В Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Или для релиза: **Build → Generate Signed Bundle / APK**
3. APK будет в `app/build/outputs/apk/debug/app-debug.apk`

#### Шаг 9: Установка на Redmi Note 14
1. Включите **Режим разработчика**: Настройки → О телефоне → 7 раз нажмите на "Версия MIUI"
2. Включите **Отладку по USB**: Настройки → Дополнительные настройки → Для разработчиков → Отладка по USB
3. Подключите телефон к ПК
4. В Android Studio нажмите зелёную стрелку **Run** (или Shift+F10)

---

### Способ 2: PWA (Progressive Web App) — самый простой

1. Залейте содержимое папки `dist/` на хостинг:
   - GitHub Pages (бесплатно)
   - Netlify (бесплатно)
   - Vercel (бесплатно)
   - Любой другой хостинг

2. Откройте сайт в Chrome на Redmi Note 14

3. Нажмите **⋮ → Добавить на главный экран**

4. Приложение появится на рабочем столе и будет работать как нативное!

---

### Способ 3: WebView Gold / Website2APK

Если не хотите программировать:

1. Установите из Google Play: **Website2APK Builder** или **WebView Gold**
2. Укажите URL вашего задеплоенного сайта
3. Соберите APK одной кнопкой

---

## Оптимизация под Redmi Note 14

| Параметр | Значение |
|----------|----------|
| Экран | 6.67" AMOLED, 1080×2400 |
| Плотность пикселей | ~395 ppi |
| Соотношение сторон | 20:9 |

Браузер уже адаптирован:
- Боковая панель скрывается на экранах < 768px
- Плитки Speed Dial перестраиваются в 2 колонки
- Кнопки увеличены для точного нажатия пальцем
- Поддержка жестов масштабирования в WebView

## Устранение неполадок

**Проблема**: Белый экран вместо браузера
**Решение**: Проверьте, что все файлы из `dist/` скопированы в `assets/browser/`

**Проблема**: Не работает JavaScript
**Решение**: Убедитесь, что `webSettings.javaScriptEnabled = true`

**Проблема**: Сайты не загружаются в iframe
**Решение**: Это ограничение безопасности (X-Frame-Options). Для Android используйте WebView вместо iframe (см. код MainActivity выше — он загружает HTML-интерфейс, а сайты будут открываться внутри него).

**Проблема**: Медленная загрузка
**Решение**: Включите кэширование: `webSettings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK`
